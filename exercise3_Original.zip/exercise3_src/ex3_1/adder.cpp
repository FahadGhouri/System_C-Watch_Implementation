#include "adder.h"
void Adder::add()
{
  s = x + y;
}
